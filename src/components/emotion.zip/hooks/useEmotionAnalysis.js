// src/services/emotionApi.js
import axios from "axios";

const FASTAPI_URL = process.env.REACT_APP_FAST_URL;

/**
 * 감정 분석 요청
 * @param {string} email - 사용자 이메일 (세션에서 관리 중인 값 사용)
 * @param {string} text  - 사용자 입력 문장
 * @returns {Promise<object>} JSON { happiness, sadness, anger, anxiety, calmness, etc }
 */
export async function requestEmotionAnalysis(email, text) {
  try {
    const response = await axios.post(
      `${FASTAPI_URL}/api/emotion/analyze`,
      { email, text }, // ✅ email + text만 전달
      { headers: { "Content-Type": "application/json" } }
    );

    return response.data;
  } catch (err) {
    console.error("감정 분석 요청 실패:", err.response?.data || err.message);
    return null;
  }
}
